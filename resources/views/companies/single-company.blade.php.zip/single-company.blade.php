<x-layout>


 @section('title')
{{$company->Name}} 
@endsection
    <section class="article-inner bg-light">
        <div class="container">
            <div class="row">
             
                <div class="col-lg-12 col-md-12">
                  <div class="adv-slider" id="section-slider">
                      <div class="single-items"><img src="<?php if (isset($company)){echo URL::to('/').'/images/'.$company->photo  ;} ?>"  class="img-fluid" alt=""></div> 

                  </div>
                </div>
                
                
                
            </div>
            
            
            
            
            
            
                        <div class="row">

            
               <div class="col-lg-6">
                  <div class="portfolio-info">
                      <ul>
                          
                       
                     
                     
                          <li><strong>    {{ trans('langsite.Address')}}    </strong>:
                             {{ $company->governrateq->governrate}}   
                            @if($company->district_ashraf)  , {{ $company->district_ashraf->district}}@endif  
                            @if($company->subArea)  , {{ $company->subArea->area}}@endif 
                            
                          
                            
                        </li>
                     
                   
                   
                     <li> 
                           
                        <strong>      الدور  </strong>  
                                                    @if($company->Floor )

                        {{ $company->Floor }}
                                    @else
                        لا يوجد
                         
                        @endif
                          
                            
                        </li>
                        
                        
                        <li> 
                         <strong>   عماره رقم</strong>
                         
                                                     @if( $company->building_number )

                         {{ $company->building_number }}  
                                     @else
                        لا يوجد
                         
                         @endif
                          
                            
                        </li>
                     
                   
                   
                   
                   
                   
                        
                     <li> 
                        
                          <strong> الشقه رقم </strong>
                          @if($company->unit_number)

                          {{ $company->unit_number }} 
                                  @else
                        لا يوجد
                           
                            @endif
                            
                        </li>
                     
                   
             
                     
                          
                        
                        
                        
                      </ul>
                    </div>
                </div>
                
                    <div class="col-lg-6">
                  <div class="portfolio-info">
                      <ul>
                          
                        <li><strong>{{ trans('langsite.Section')}}</strong>:
                            @if(App::isLocale('ar'))
                    {{ $company->serv->Service }}  
                    @else
                    {{ $company->serv->Service_en }}  
                    @endif
                        
                          
                        
                        </li>  
                        <li><strong>{{ trans('langsite.company-name')}}</strong>:
                        
                        
                       {{ $company->Name }}   
                        
                        </li>
                        <li><strong>{{ trans('langsite.Phone')}}</strong>:
                             <a href="tel:{{ $company->Phone }}">{{ $company->Phone }}</a>   
                        </li>
                    
                      <li><strong>{{ trans('langsite.landline')}}</strong>:
                      
                        @if( $company->landline ) 
                             <a href="tel:{{ $company->landline }}">{{ $company->landline }}</a> 
                                 
                                @else
                        لا يوجد
                            
                             @endif
                        </li>
                     
                     
                       
                      <li><strong> رقم البطاقه الضريبيه</strong>:
                      
                       @if( $company->Tax_card ) 
                            {{ $company->Tax_card }}    
                            
                                @else
                        لا يوجد
                               
                             @endif
                        </li>
                    
                     
                     
                      <li>
                          <strong>  رقم السجل التجاري    </strong>:
                                               @if( $company->Commercial_Register ) 

                            {{ $company->Commercial_Register }}    
                            @else
                        لا يوجد
                                @endif
                                
                        </li>
                 
                     
                  
             
                    
                        
                        
                        
                      </ul>
                    </div>
                </div>
                
                
                
                
                  </div>
                
                    <section class="" dir="ltr">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-7 col-md-10 text-center">
                    <div class="sec-heading center mb-4">
                        <h2 class="headingTitle"> العقارات   </h2>
                        <p>

                            يمكنك مشاهدة أكثر العقارات مناسبة لطلباتك من حيث المساحة أو الموقع أو السعر
                        </p>
                    </div>
                </div>
            </div>





                
                
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="property-slide">

                        @foreach ($allAqars as $aqarSim)
                        <div class="single-items">
                            <div class="property-listing shadow-none property-2 border">

                                <div class="listing-img-wrapper">

                                    <div class="list-img-slide">
                                        <div class="click">


                                            <div>
                                                <a href="{{ URL::to(Config::get('app.locale').'/aqars/' . $aqarSim->slug) }}"  target="_blank">
                                                    
                                                       
              @if($aqarSim->mainImage)
                                 <img src="{{ URL::to('/').'/images/'.$aqarSim->mainImage->img_url}}"   class="img-fluid mx-auto"  alt="main">
                            
                                @else
                                
							
                                                    @if($aqarSim->firstImage)
                                                    <img
                                                        src="{{ URL::to('/').'/images/'.$aqarSim->firstImage->img_url}}"
                                                        class="img-fluid mx-auto" alt="" />
                                                        
                                                     
                                                        
                                                          @else
                                        <img src="https://rightchoice-co.com/images/FBO.png" class="img-fluid main-img"
                                            alt="main">
 
                                        @endif
                                                        
                                                        
                                                        
                                                        @endif
                                                               
                                                        
                                                        </a>
                                                        
                                                        
                                                        </div>
                                                     </div>
                                    </div>
                                    <div class="views">

                                        <div class="views-2">
                                            <i class="fa fa-eye"></i>
                                            <span>{{ $aqarSim->views }}</span>

                                        </div>
                                    </div>
                                </div>

                                <div class="listing-detail-wrapper">
                                    <div class="listing-short-detail-wrap">
                                        <div class="listing-short-detail">
                                            <h4 class="listing-name verified center-name"><a
                                                    href="{{ URL::to(Config::get('app.locale').'/aqars/' . $aqarSim->slug) }}"
                                                    class=""
                                                    target="_blank">{{ \Illuminate\Support\Str::limit($aqarSim->title, $limit = 29, $end = '...') }}</a>
                                            </h4>
                                            <!-- <h4 class="listing-name verified"><a href="single-property-1.html" class="prt-link-detail">Banyon Tree Realty</a></h4> -->
                                        </div>

                                    </div>

                                </div>
                                <div class="listing-short-detail-flex">
                                    @if ($aqarSim->offer_type == 1 || $aqarSim->offer_type == 2)

                                    <h6 class="listing-card-info-price">{{ $aqarSim->total_price }}
                                        {{ trans('langsite.egyptian_pound') }}</h6>

                                    @endif
                                    @if ($aqarSim->offer_type == 3 || $aqarSim->offer_type == 4)
                                    <h6 class="listing-card-info-price">{{ $aqarSim->monthly_rent }}
                                        {{ trans('langsite.egyptian_pound') }}</h6>

                                    @endif

                                </div>
                                <div class="price-features-wrapper">
                                    <div class="list-fx-features">





                                        <div class="listing-card-info-icon">
                                            {{ $aqarSim->baths }} حمام
                                            <div class="inc-fleat-icon"><img src="{{ asset('images/icons/bath.png') }}"
                                                    width="12" alt="" /></div>
                                        </div>
                                        <div class="listing-card-info-icon">
                                            {{ $aqarSim->rooms }} غرف
                                            <div class="inc-fleat-icon"><img src="{{ asset('images/icons/room.png') }}"
                                                    width="12" alt="" /></div>
                                        </div>

                                        <div class="listing-card-info-icon">
                                            {{ $aqarSim->total_area }} م²
                                            <div class="inc-fleat-icon"><img src="{{ asset('images/icons/area.png') }}"
                                                    width="12" alt="" /></div>
                                        </div>


                                    </div>
                                </div>

                                <div class="listing-detail-footer bg-light">
                                    <div class="footer-first">
                                        <div class="foot-location">
                                            @if ($aqarSim->governrateq)
                                            {{ $aqarSim->governrateq->governrate }}
                                            @endif
                                            @if ($aqarSim->districte)
                                          ,  {{ $aqarSim->districte->district }}
                                            @endif
                                            @if ($aqarSim->subAreaa)
                                            {{ $aqarSim->subAreaa->area }},
                                            @endif

                                            <img src="{{ asset('assets/img/pin.svg') }}" width="18" alt="" />
                                        </div>
                                    </div>
                                    <div class="footer-flex">
                                        <a href="{{ URL::to(Config::get('app.locale').'/aqars/' . $aqarSim->slug) }}"
                                            class="prt-view" target="_blank">عرض</a>
                                        <!-- <a href="property-detail.html" class="prt-view">View</a> -->
                                    </div>
                                </div>

                            </div>
                        </div>
                        @endforeach


                    </div>
                </div>
            </div>





        </div>
    </section>












                
           
        </div>
    </section>


    
    <div >
        	<!-- ============================ Call To Action ================================== -->
								<x-call-to-action />
		<!-- ============================ Call To Action End ================================== -->
    </div>
    
	

</x-layout>